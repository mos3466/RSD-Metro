# RASD code review and change report

## Scope
Changes are applied to the existing RASD project. No UI redesign or replacement project was created.

## Bugs found and addressed
1. An RFID UID repeated on an active trip was implicitly treated as an exit after the cooldown. The backend had no entry/exit distinction.
2. A `HOLD` passenger decision changed the trip status to `hold`, which removed the trip from the active-trip selection.
3. Retry handling inferred the repeated exit result from trip status, which could return the wrong passenger decision after a held trip remained active.
4. Incident review listing included confirmed/rejected filters in the same review surface; review mutations did not require the incident to still be pending.
5. Dashboard confirmed/rejected counters were scoped to the current day while pending was all-time.
6. Retention cleanup deleted old incidents and detections, and could delete active trips.
7. Detection ingestion had no duplicate lookup for repeated identical event payloads.

## Changes made
- Added explicit `direction` (`entry`/`exit`) to the RFID bridge payload. Missing direction safely defaults to `entry`.
- An active trip scanned by an entry reader remains active. Only an explicitly configured exit reader can complete a trip.
- `HOLD` now changes the passenger decision, not the trip lifecycle; the trip remains active and keeps its Trip ID.
- Persisted `lastScanAt` and `lastScanDecision` so cooldowns use the most recent scan and retries return the same decision.
- Exit scans without an active trip return `SCAN_ERROR` rather than creating a new trip at an exit gate.
- The review queue now requests and displays Pending only.
- Review updates apply only to records still Pending. Reviewed records remain stored.
- Dashboard counters count all currently stored detections and incidents by actual status.
- Retention cleanup preserves all incidents and their source detections, all active/held trips, and completed trips linked to incidents. It removes only old orphan detections and unlinked completed trips.
- Added sequential duplicate detection lookup for identical camera/type/time/trip/tracking payloads.
- Added an explicit database migration and a `db:migrate` package script.
- Documented the future LCD response protocol without changing the checked-in Arduino sketch.

## Files modified
- `server/db.ts`
- `server/rfidBridge.ts`
- `server/rfid.test.ts`
- `client/src/pages/Home.tsx`
- `drizzle/schema.ts`
- `drizzle/meta/_journal.json`
- `drizzle/meta/0005_snapshot.json`
- `hardware/rfid_bridge.py`
- `hardware/README.md`
- `package.json`

## Files added
- `drizzle/0005_rfid_scan_state.sql`
- `hardware/protocol.md`
- `RASD_CHANGE_REPORT.md`

## Checks performed
- Python bridge syntax compilation: PASS.
- TypeScript/TSX syntax transpilation for changed server, client, schema, and test files: PASS.
- Migration metadata JSON parsing: PASS.
- Full TypeScript type-check, Vitest suite, and production build: NOT RUN. Project dependencies are not installed in this environment and package-manager download was unavailable (network/DNS failure).
- Live MySQL migration and data-retention behavior: NOT RUN; requires the project's configured `DATABASE_URL`.
- Physical Arduino/RFID/LCD integration: NOT RUN; no hardware is connected in this environment.

## Remaining issues and deployment requirements
1. Apply migration `0005_rfid_scan_state.sql` before running the updated backend: from the project root run `pnpm install`, configure `DATABASE_URL`, then `pnpm db:migrate`.
2. Install dependencies and run `pnpm test`, `pnpm check`, and `pnpm build` in the actual project environment.
3. The archive's `hardware/arduino_rfid_rc522.ino` contains RFID/Serial output only. It does not include LCD/I2C initialization or a serial response parser, despite the separate LCD hardware reportedly working. The independent LCD sketch was not supplied in this archive.
4. The current Python bridge receives the real API decision but only prints it. It does not yet send a result line back to the Arduino. Complete that only after merging the actual LCD sketch and testing its I2C address/wiring. The planned serial response contract is in `hardware/protocol.md`.
5. Use separate physical entry and exit readers, configuring `RSD_SCAN_DIRECTION=entry` or `exit` for each bridge. One undirected reader cannot determine passenger direction from a UID alone.
6. Duplicate camera event lookup is sequential protection. A database-level unique event key would be required to guarantee deduplication under simultaneous concurrent ingestion; the current schema does not expose a stable source event ID.

## LCD integration notes from the earlier review
- Provide the exact currently working LCD + RC522 `.ino` source and confirm the LCD I2C address.
- Merge the existing LCD code with the unchanged `RFID_UID=` output.
- Add a bounded serial parser for `RASD_RESULT=TRIP_ACTIVE`, `EXIT_ALLOWED`, `HOLD`, and `ERROR`.
- Extend the Python bridge to write the result returned by the authenticated RASD API back over the same serial port.
- Verify each LCD message using real API responses; never synthesize passenger status locally.


## Arduino LCD two-way integration update

The supplied working Arduino sketch was merged into `hardware/arduino_rfid_rc522.ino`: LCD/I2C initialization and messages are retained, the exact `RFID_UID=` prefix and 115200 baud are preserved, and a serial response parser handles `RASD_RESULT=...`. The Python bridge now returns only allow-listed backend decisions (`TRIP_ACTIVE`, `EXIT_ALLOWED`, `HOLD`, `SCAN_ERROR`) to Arduino; HTTP 4xx errors return `SCAN_ERROR`, while server/network errors retry. This uses a local USB Serial bridge, not direct browser-to-Arduino communication. Physical validation remains required; confirm the LCD I2C address is `0x27` before upload.

## Current RFID/LCD integration update

- Aligned the Arduino duplicate-tap guard with the backend default: repeated scans of the same UID are ignored for 5 seconds.
- Changed the successful entry result (`TRIP_ACTIVE`) to display `Scan Your Card` as requested; exit and hold messages remain `Good Bye` and `Refer to Staff`.
- Added an allow-listed `SCAN_ERROR` decision and type-safe decision mapping in `hardware/rfid_bridge.py`.
- Added `hardware/test_rfid_bridge.py`, a dependency-free protocol test using a fake serial device; it does not claim to test physical hardware or a live API.
- Updated `hardware/protocol.md` to document the final result mapping and the shared 5-second guard.
- Replaced the POSIX-only `NODE_ENV=...` package scripts so `pnpm dev` works in Windows CMD/PowerShell.
- Made development mode the default unless `NODE_ENV=production` is explicitly selected.
- Added placeholder detection for `mysql://USER:PASSWORD@HOST:3306/DATABASE`; the server now disables persistence with a clear warning instead of attempting a DNS lookup for `HOST`.
- Added a regression test for the placeholder database URL and documented that a real MySQL/TiDB URL is still required for persistent RFID trips.
