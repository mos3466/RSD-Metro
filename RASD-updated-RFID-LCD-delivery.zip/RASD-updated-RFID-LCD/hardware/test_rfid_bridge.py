import importlib.util
import sys
import types
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent


class RfidBridgeProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Load the bridge with a small serial stub so these protocol tests do not
        # require pyserial or a physical Arduino.
        serial_stub = types.ModuleType("serial")
        serial_stub.SerialException = RuntimeError
        sys.modules.setdefault("serial", serial_stub)
        spec = importlib.util.spec_from_file_location("rfid_bridge_under_test", ROOT / "rfid_bridge.py")
        cls.bridge = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(cls.bridge)

    def test_backend_decisions_are_allow_listed(self):
        self.assertEqual(self.bridge.lcd_result_for_decision("TRIP_ACTIVE"), "TRIP_ACTIVE")
        self.assertEqual(self.bridge.lcd_result_for_decision("EXIT_ALLOWED"), "EXIT_ALLOWED")
        self.assertEqual(self.bridge.lcd_result_for_decision("HOLD"), "HOLD")
        self.assertEqual(self.bridge.lcd_result_for_decision("SCAN_ERROR"), "SCAN_ERROR")
        self.assertEqual(self.bridge.lcd_result_for_decision("unexpected"), "SCAN_ERROR")
        self.assertEqual(self.bridge.lcd_result_for_decision({}), "SCAN_ERROR")

    def test_serial_response_line_is_exact(self):
        class FakeDevice:
            def __init__(self):
                self.writes = []

            def write(self, value):
                self.writes.append(value)

            def flush(self):
                pass

        device = FakeDevice()
        self.bridge.send_lcd_result(device, "HOLD")
        self.assertEqual(device.writes, [b"RASD_RESULT=HOLD\n"])


if __name__ == "__main__":
    unittest.main()
