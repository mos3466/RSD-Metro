#!/usr/bin/env python3
"""RSD Arduino Uno + RC522 USB Serial bridge for Windows, Linux, and macOS.

The bridge reads lines such as RFID_UID=AA:BB:CC:DD and forwards each scan
with a stable event ID until the server acknowledges it. The raw UID is sent
only over the configured HTTPS connection and is never written to disk or
printed in logs.
"""

import argparse
import json
import os
import sys
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

try:
    import serial
    from serial import SerialException
except ImportError:
    print("Missing dependency: pyserial. Run: python -m pip install -r hardware/requirements.txt", file=sys.stderr)
    raise


def parse_args():
    parser = argparse.ArgumentParser(description="Forward Arduino RC522 RFID scans to RSD")
    parser.add_argument("--port", default=os.environ.get("RSD_SERIAL_PORT", "COM5" if os.name == "nt" else "/dev/ttyACM0"), help="Arduino USB Serial port, e.g. COM3")
    parser.add_argument("--baud", type=int, default=int(os.environ.get("RSD_SERIAL_BAUD", "115200")), help="Serial speed; must match Arduino sketch")
    parser.add_argument("--api-url", default=os.environ.get("RSD_API_URL", ""), help="RSD site base URL, without /api/rfid/trips")
    return parser.parse_args()


def post_trip(api_url: str, bridge_key: str, uid: str, event_id: str, direction: str):
    endpoint = api_url.rstrip("/") + "/api/rfid/trips"
    payload = json.dumps({"uid": uid, "eventId": event_id, "startedAt": int(time.time() * 1000), "direction": direction}).encode("utf-8")
    request = Request(
        endpoint,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-RSD-Bridge-Key": bridge_key,
            "User-Agent": "RSD-RFID-Bridge/1.0",
        },
    )
    with urlopen(request, timeout=10) as response:
        return response.status, json.loads(response.read().decode("utf-8"))


ALLOWED_DECISIONS = {"TRIP_ACTIVE", "EXIT_ALLOWED", "HOLD", "SCAN_ERROR"}


def lcd_result_for_decision(decision) -> str:
    """Return only a known backend decision for the Arduino serial protocol."""
    return decision if isinstance(decision, str) and decision in ALLOWED_DECISIONS else "SCAN_ERROR"


def send_lcd_result(device, decision: str):
    # Only forward a recognized decision returned by the backend.
    result = lcd_result_for_decision(decision)
    device.write(f"RASD_RESULT={result}\n".encode("ascii"))
    device.flush()


def send_until_ack(device, api_url: str, bridge_key: str, uid: str, event_id: str, retry_seconds: float, direction: str):
    while True:
        try:
            _, result = post_trip(api_url, bridge_key, uid, event_id, direction)
            decision = result.get("decision", "SCAN_ERROR")
            send_lcd_result(device, decision)
            trip = result.get("trip") or {}
            message = result.get("message", "")
            print(f"Trip {trip.get('tripId', 'not available')} · {decision}{' · ' + message if message else ''}{' (duplicate retry)' if result.get('duplicate') else ''}", flush=True)
            return True
        except HTTPError as error:
            if 400 <= error.code < 500:
                print(f"RSD API rejected the scan with HTTP {error.code}; check the bridge key and payload.", file=sys.stderr)
                send_lcd_result(device, "SCAN_ERROR")
                return False
            print(f"RSD API server error ({error.code}); retrying in {retry_seconds:g}s", file=sys.stderr)
            time.sleep(retry_seconds)
        except (URLError, TimeoutError, OSError, json.JSONDecodeError) as error:
            print(f"RSD API unavailable or invalid response ({error}); retrying in {retry_seconds:g}s", file=sys.stderr)
            time.sleep(retry_seconds)


def main():
    args = parse_args()
    bridge_key = os.environ.get("RSD_BRIDGE_API_KEY", "")
    if not args.api_url or not bridge_key:
        missing = []
        if not args.api_url:
            missing.append("RSD_API_URL or --api-url")
        if not bridge_key:
            missing.append("RSD_BRIDGE_API_KEY")
        raise SystemExit("Missing required configuration: " + ", ".join(missing))
    if args.baud <= 0:
        raise SystemExit("Baud rate must be a positive integer")

    retry_seconds = float(os.environ.get("RSD_RETRY_SECONDS", "2"))
    direction = os.environ.get("RSD_SCAN_DIRECTION", "entry").strip().lower()
    if direction not in ("entry", "exit"):
        raise SystemExit("RSD_SCAN_DIRECTION must be 'entry' or 'exit'")
    print(f"RSD RFID bridge listening on {args.port} at {args.baud} baud")
    try:
        with serial.Serial(args.port, args.baud, timeout=0.2, write_timeout=2) as device:
            # Uno boards commonly reset when a serial connection is opened.
            time.sleep(2)
            device.reset_input_buffer()
            while True:
                raw_line = device.readline().decode("utf-8", errors="ignore").strip()
                if not raw_line.startswith("RFID_UID="):
                    continue
                uid = raw_line.split("=", 1)[1].strip().upper()
                if not uid:
                    continue
                # Keep the event ID stable for all retries of this scan.
                event_id = f"arduino-{uuid.uuid4()}"
                send_until_ack(device, args.api_url, bridge_key, uid, event_id, retry_seconds, direction)
    except SerialException as error:
        raise SystemExit(f"Unable to open {args.port}. Close Arduino Serial Monitor and check Device Manager: {error}") from error


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nRSD RFID bridge stopped")
